﻿namespace IntegrateAPI
{
    public class Employee
    {
        public int emploeeID { get; set; }
        public string employeeName { get; set; }
        public string employeeEmail { get; set; }
        public string employeePhone { get; set; }
    }
}
